#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <string>
#include <map>

#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "camera.h"  // Camera class
#include "Enums.h"
#include "shader_m.h"
#include "filesystem.h"
#include "Model.h"

#include <iostream>
using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace
{
    const char* const WINDOW_TITLE = "Dre Scheetz Milestone"; // Macro for window title
    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;
    // Main GLFW window
    GLFWwindow* gWindow = nullptr;

    // camera
    Camera gCamera(glm::vec3(0.0f, 1.0f, 5.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    bool viewProjection = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    glm::vec3 pointLightPositions[] = {
         glm::vec3(-2.0f, 3.0f, 0.0f),
         glm::vec3(2.0f, 3.0f, 0.0f)
    };
}

bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void URender(std::vector<Model*> models, Shader& objectShader);

int main(int argc, char* argv[])
{
    // Program start
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;
    // tell stb_image.h to flip loaded texture's on the y-axis (before loading model).
    stbi_set_flip_vertically_on_load(true);
    // build and compile shaders
     // -------------------------
     //Shader ourShader("1.model_loading.vs", "1.model_loading.fs");
    Shader objectShader("cube.vs", "cube.fs");

    // load models with models positions, scales, rotation, and shininess. Put the model into a vector
    // ----------- 
    std::vector<Model*> models;
    Model desk(FileSystem::getPath("../objects/desk/desk.obj"), glm::vec3(0.0f, 0.0f, -0.5f), glm::vec3(2.0f, 0.0f, 2.0f),
        1.5708f, glm::vec3(0.0f, 1.0f, 0.0f), 1.0f);
    models.push_back(&desk);
    Model can(FileSystem::getPath("../objects/can/can.obj"), glm::vec3(1.8f, 0.45f, 0.8f), glm::vec3(0.1f, 0.1f, 0.1f),
        3.0f, glm::vec3(0.0f, 1.0f, 0.0f), 0.1f);
    models.push_back(&can);
    Model pencil(FileSystem::getPath("../objects/pencil/pencil.obj"), glm::vec3(-0.8f, 0.05f, 1.4f), glm::vec3(0.05f, 0.05f, 0.05f),
        -2.0f, glm::vec3(0.0f, 1.0f, 0.0f), 0.5f);
    models.push_back(&pencil);
    Model bookCover(FileSystem::getPath("../objects/bookCover/bookCover.obj"), glm::vec3(-2.0f, 0.18f, 0.2f), glm::vec3(1.0f, 1.0f, 1.0f),
        0.5f, glm::vec3(0.0f, 1.0f, 0.0f), 0.5f);
    models.push_back(&bookCover);
    Model bookPages(FileSystem::getPath("../objects/bookPage/bookPage.obj"), glm::vec3(-2.0f, 0.2f, 0.2f), glm::vec3(1.0f, 1.0f, 1.0f),
        0.5f, glm::vec3(0.0f, 1.0f, 0.0f), 0.1f);
    models.push_back(&bookPages);
    Model laptop(FileSystem::getPath("../objects/laptop/laptop.obj"), glm::vec3(2.0f, 0.1f, -1.5f), glm::vec3(1.5f, 1.5f, 1.5f),
        -0.5f, glm::vec3(0.0f, 1.0f, 0.0f), 0.5f);
    models.push_back(&laptop);
    Model laptopScreen(FileSystem::getPath("../objects/laptopScreen/laptopScreen.obj"), glm::vec3(2.0f, 0.1f, -1.5f), glm::vec3(1.5f, 1.5f, 1.5f),
        -0.5f, glm::vec3(0.0f, 1.0f, 0.0f), 1.0f);
    models.push_back(&laptopScreen);
    Model globe(FileSystem::getPath("../objects/globe/globe.obj"), glm::vec3(-3.5f, -0.05f, -2.5f), glm::vec3(0.5f, 0.5f, 0.5f),
        -0.5f, glm::vec3(0.0f, 1.0f, 0.0f), 0.8f);
    models.push_back(&globe);
    Model globeStand(FileSystem::getPath("../objects/globeStand/globeStand.obj"), glm::vec3(-3.5f, 0.0f, -2.5f), glm::vec3(0.2f, 0.2f, 0.2f),
        -0.5f, glm::vec3(0.0f, 1.0f, 0.0f), 1.0f);
    models.push_back(&globeStand);
    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        UProcessInput(gWindow);
        
        // render
        // Enable z-depth
        glEnable(GL_DEPTH_TEST);
        glClearColor(0.05f, 0.05f, 0.05f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        URender(models, objectShader);
      
        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(gWindow);
        glfwPollEvents();
    }

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}

bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 5.0f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        viewProjection = !viewProjection;
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

void URender(std::vector<Model*> models, Shader& objectShader)
{   
    // view/projection transformations
    glm::mat4 view = gCamera.GetViewMatrix();
    glm::mat4 projection;
    if (viewProjection) {
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else {
        float scale = 200;
        projection = glm::ortho(-(800.0f / scale), (800.0f / scale), -(600.0f / scale), (600.0f / scale), 0.0f, 100.0f);
    }
    objectShader.use();
    objectShader.setInt("material.diffuse", 0);
    objectShader.setInt("material.specular", 1);

    // point light 1
    objectShader.setVec3("pointLights[0].position", pointLightPositions[0]);
    objectShader.setVec3("pointLights[0].ambient", 1.0f, 0.2f, 1.0f);

    objectShader.setFloat("pointLights[0].constant", 1.0f);
    objectShader.setFloat("pointLights[0].linear", 0.09f);
    objectShader.setFloat("pointLights[0].quadratic", 0.032f);
    // point light 2
    objectShader.setVec3("pointLights[1].position", pointLightPositions[1]);
    objectShader.setVec3("pointLights[1].ambient", 0.8f, 0.6f, 0.4f);
    objectShader.setVec3("pointLights[1].diffuse", 0.05f, 0.05f, 0.05f);
    objectShader.setVec3("pointLights[1].specular", 0.3f, 0.3f, 0.3f);
    objectShader.setFloat("pointLights[1].constant", 1.0f);
    objectShader.setFloat("pointLights[1].linear", 0.09f);
    objectShader.setFloat("pointLights[1].quadratic", 0.032f);
    // spotLight
    objectShader.setVec3("spotLight.position", 2.9f, 0.5f, -1.6f);
    objectShader.setVec3("spotLight.direction", 2.9f, 0.8f, 0.0f);
    objectShader.setVec3("spotLight.ambient", 0.3f, 0.3f, 0.5f);
    objectShader.setVec3("spotLight.diffuse", 0.5f, 0.5f, 0.5f);
    objectShader.setVec3("spotLight.specular", 0.5f, 0.5f, 0.5f);
    objectShader.setFloat("spotLight.constant", 1.0f);
    objectShader.setFloat("spotLight.linear", 0.09f);
    objectShader.setFloat("spotLight.quadratic", 0.032f);
    objectShader.setFloat("spotLight.cutOff", glm::cos(glm::radians(10.5f)));
    objectShader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(350.0f)));

    // Retrieves and passes transform matrices to the Shader program
    objectShader.setMat4("projection", projection);
    objectShader.setMat4("view", view);

    glm::mat4 model;
    for (unsigned int i = 0; i < models.size(); ++i)
    {
        objectShader.setFloat("material.shininess", models[i]->getShininess());
        model = glm::mat4(1.0f);
        model = glm::translate(model, models[i]->getObjectPosition()); // translate it down so it's at the center of the scene
        model = glm::scale(model, models[i]->getObjectScale());	// it's a bit too big for our scene, so scale it down
        model = glm::rotate(model, models[i]->getObjectAngle(), models[i]->getObjectRotation());
        // render the loaded model

        objectShader.setMat4("model", model);
        models[i]->Draw(objectShader);
    }
}
