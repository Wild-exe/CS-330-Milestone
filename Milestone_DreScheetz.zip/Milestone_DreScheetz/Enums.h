#pragma once
class Enums
{
public:
    enum class ModelData
    {
        desk,
        pencil,
        can,
        bookCover,
        bookPage,
        laptop,
        laptopScreen,
        globe,
        globeStand,
    };
};